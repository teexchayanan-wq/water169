<?php
return [
    'db_host' => 'localhost',
    'db_user' => 'YOUR_DATABASE_USER',
    'db_pass' => 'YOUR_DATABASE_PASSWORD',
    'db_name' => 'YOUR_DATABASE_NAME',
    'admin_password' => 'CHANGE_THIS_ADMIN_PASSWORD'
];
