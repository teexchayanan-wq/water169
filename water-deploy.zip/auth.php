<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

function water_admin_password() {
    $configPath = __DIR__ . '/db_config.php';
    $config = file_exists($configPath) ? require $configPath : [];
    return getenv('WATER_ADMIN_PASSWORD') ?: ($config['admin_password'] ?? 'gundamman');
}

function water_is_admin() {
    return !empty($_SESSION['water_admin']);
}

function water_require_admin_json() {
    if (water_is_admin()) return;

    http_response_code(401);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'status' => 'error',
        'message' => 'Unauthorized'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}
?>
