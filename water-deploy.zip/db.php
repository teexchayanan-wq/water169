<?php
$configPath = __DIR__ . '/db_config.php';
$config = file_exists($configPath) ? require $configPath : [];

$dbHost = getenv('WATER_DB_HOST') ?: ($config['db_host'] ?? 'localhost');
$dbUser = getenv('WATER_DB_USER') ?: ($config['db_user'] ?? 'root');
$dbPass = getenv('WATER_DB_PASS') ?: ($config['db_pass'] ?? '');
$dbName = getenv('WATER_DB_NAME') ?: ($config['db_name'] ?? 'urine_monitoring_system');

$conn = new mysqli($dbHost, $dbUser, $dbPass, $dbName);

if ($conn->connect_error) {
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        "status" => "error",
        "message" => "Database connection failed"
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$conn->set_charset("utf8mb4");
?>
