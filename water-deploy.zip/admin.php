<?php
require __DIR__ . '/auth.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $password = $_POST['password'] ?? '';

    if (hash_equals(water_admin_password(), $password)) {
        $_SESSION['water_admin'] = true;
        header('Location: admin.php');
        exit;
    }

    $error = 'รหัสผ่านไม่ถูกต้อง';
}

if (water_is_admin()) {
    readfile(__DIR__ . '/admin.html');
    exit;
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>เข้าสู่ระบบผู้ดูแล</title>
    <style>
        * { box-sizing: border-box; }
        body {
            min-height: 100vh;
            margin: 0;
            display: grid;
            place-items: center;
            font-family: 'Segoe UI', Tahoma, sans-serif;
            background: #eef6f8;
            color: #102033;
            padding: 20px;
        }
        .login-box {
            width: 100%;
            max-width: 390px;
            background: #fff;
            border: 1px solid #d8e4ea;
            border-radius: 12px;
            box-shadow: 0 18px 45px rgba(15, 35, 52, 0.12);
            padding: 24px;
        }
        h1 { margin: 0 0 6px; font-size: 22px; color: #0f3f56; }
        p { margin: 0 0 18px; color: #617082; }
        label { display: block; margin-bottom: 8px; font-weight: 700; }
        input {
            width: 100%;
            min-height: 44px;
            border: 1px solid #b9cad4;
            border-radius: 8px;
            padding: 10px 12px;
            font-size: 16px;
        }
        button {
            width: 100%;
            min-height: 44px;
            margin-top: 16px;
            border: 0;
            border-radius: 8px;
            background: #0f766e;
            color: #fff;
            font-weight: 700;
            cursor: pointer;
        }
        .error {
            background: #fee2e2;
            color: #991b1b;
            border: 1px solid #fecaca;
            border-radius: 8px;
            padding: 10px;
            margin-bottom: 14px;
        }
        a { display: inline-block; margin-top: 14px; color: #0f766e; text-decoration: none; }
    </style>
</head>
<body>
    <form class="login-box" method="post" action="admin.php">
        <h1>เข้าสู่ระบบผู้ดูแล</h1>
        <p>ระบบเฝ้าระวังภาวะขาดน้ำทหารใหม่</p>
        <?php if ($error): ?>
            <div class="error"><?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></div>
        <?php endif; ?>
        <label for="password">รหัสผ่านผู้ดูแล</label>
        <input id="password" name="password" type="password" autocomplete="current-password" required autofocus>
        <button type="submit">เข้าสู่ระบบ</button>
        <a href="index.html">กลับหน้าบันทึกข้อมูล</a>
    </form>
</body>
</html>
