-- MySQL dump 10.13  Distrib 8.4.3, for Win64 (x86_64)
--
-- Host: localhost    Database: urine_monitoring_system
-- ------------------------------------------------------
-- Server version	8.4.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `urine_monitoring_system`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `urine_monitoring_system` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `urine_monitoring_system`;

--
-- Temporary view structure for view `daily_summary`
--

DROP TABLE IF EXISTS `daily_summary`;
/*!50001 DROP VIEW IF EXISTS `daily_summary`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `daily_summary` AS SELECT 
 1 AS `record_date`,
 1 AS `time_period`,
 1 AS `urine_level`,
 1 AS `total`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `full_report`
--

DROP TABLE IF EXISTS `full_report`;
/*!50001 DROP VIEW IF EXISTS `full_report`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `full_report` AS SELECT 
 1 AS `id`,
 1 AS `record_date`,
 1 AS `time_period`,
 1 AS `urine_level`,
 1 AS `soldier_code`,
 1 AS `full_name`,
 1 AS `group_name`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `soldiers`
--

DROP TABLE IF EXISTS `soldiers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `soldiers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `soldier_code` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `full_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `group_id` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `soldier_code` (`soldier_code`),
  KEY `group_id` (`group_id`),
  CONSTRAINT `soldiers_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `training_groups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=310 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `soldiers`
--

LOCK TABLES `soldiers` WRITE;
/*!40000 ALTER TABLE `soldiers` DISABLE KEYS */;
INSERT INTO `soldiers` VALUES (61,'A-01','พลฯ กฤษกร แสงใสแก้ว',1,'2026-05-25 01:36:33'),(62,'A-02','พลฯ ชยานันต์ ขจิตสุวรรณ',1,'2026-05-25 01:36:33'),(63,'A-03','พลฯ อนุสรณ์ บัวทอง',1,'2026-05-25 01:36:33'),(64,'A-04','พลฯ สิธร จอมพงษ์',1,'2026-05-25 01:36:33'),(65,'A-05','พลฯ นพเก้า โพธิรักษ์',1,'2026-05-25 01:36:33'),(66,'A-06','พลฯ พัสกร สรรพสาร',1,'2026-05-25 01:36:33'),(67,'A-07','พลฯ ธนเดช ช้างจันทร์',1,'2026-05-25 01:36:33'),(68,'A-08','พลฯ ปกรณ์ ด้วงสงค์',1,'2026-05-25 01:36:33'),(69,'A-09','พลฯ วุฒธิพัตร มังคะละ',1,'2026-05-25 01:36:33'),(70,'A-10','พลฯ ธรรมนูญ พึ่งพวก',1,'2026-05-25 01:36:33'),(71,'A-11','พลฯ รัตนชัย ชดเชย',1,'2026-05-25 01:36:33'),(72,'A-12','พลฯ นนทกานต์ จันทร์ฯ',1,'2026-05-25 01:36:33'),(73,'A-13','พลฯ นนทภัทร อ่ำเอี่ยม',1,'2026-05-25 01:36:33'),(74,'A-14','พลฯ เจษฎา จีนแจ้ง',1,'2026-05-25 01:36:33'),(75,'A-15','พลฯ อรรถพล หงสุวรรณ์',1,'2026-05-25 01:36:33'),(76,'A-16','พลฯ นวภูมิ สุครีพ',1,'2026-05-25 01:36:33'),(77,'A-17','พลฯ ภูมิพัฒน์ เคนกุดรัง',1,'2026-05-25 01:36:33'),(78,'A-18','พลฯ จักรี นามวัน',1,'2026-05-25 01:36:33'),(79,'A-19','พลฯ ปริญญา ทองใบ',1,'2026-05-25 01:36:33'),(80,'A-20','พลฯ รัชตธร แซ่เอี่ยว',1,'2026-05-25 01:36:33'),(81,'A-21','พลฯ มงคล เจ้าสุวรรณ',1,'2026-05-25 01:36:33'),(82,'A-22','พลฯ จิรายุ แจ่มวงค์',1,'2026-05-25 01:36:33'),(83,'A-23','พลฯ ชินวัตร ชะมารัมย์',1,'2026-05-25 01:36:33'),(84,'A-24','พลฯ ธนากร จันทร์ฯ',1,'2026-05-25 01:36:33'),(85,'A-25','พลฯ ทรงพล หอมเหลือ',1,'2026-05-25 01:36:33'),(86,'A-26','พลฯ วรินทร แสงตะวัน',1,'2026-05-25 01:36:33'),(87,'A-27','พลฯ ปฏิกรณ์ พลชารี',1,'2026-05-25 01:36:33'),(88,'B-01','พลฯ กฤตภาส เหล็งบำรุง',2,'2026-05-25 01:36:33'),(89,'B-02','พลฯ ธนาคาร ลื้อประสิทธิ์',2,'2026-05-25 01:36:33'),(90,'B-03','พลฯ ธีรเมธ เกตุเม้า',2,'2026-05-25 01:36:33'),(91,'B-04','พลฯ จิรายุ อุดทา',2,'2026-05-25 01:36:33'),(92,'B-05','พลฯ เจษฎาพล อุดทา',2,'2026-05-25 01:36:33'),(93,'B-06','พลฯ สุปรีชา เสมอใจ',2,'2026-05-25 01:36:33'),(94,'B-07','พลฯ แทนไทย แสนเสนา',2,'2026-05-25 01:36:33'),(95,'B-08','พลฯ อานุภาพ เคางาม',2,'2026-05-25 01:36:33'),(96,'B-09','พลฯ อชิรวัช อภัยพิพัฒน์',2,'2026-05-25 01:36:33'),(97,'B-10','พลฯ ธวัชชัย วงศ์แดง',2,'2026-05-25 01:36:33'),(98,'B-11','พลฯ อภิชาติ บุญเกิ่ง',2,'2026-05-25 01:36:33'),(99,'B-12','พลฯ สุธิมนต์ สุภาพ',2,'2026-05-25 01:36:33'),(100,'B-13','พลฯ ชวัลวิทย์ ผดุงวิศว์',2,'2026-05-25 01:36:33'),(101,'B-14','พลฯ รัฐกรณ์ จันทะวัน',2,'2026-05-25 01:36:33'),(102,'B-15','พลฯ ศุภโชค ทองชำนาญ',2,'2026-05-25 01:36:33'),(103,'B-16','พลฯ ธนวัตน์ ดวงกระจาย',2,'2026-05-25 01:36:33'),(104,'B-17','พลฯ ศักด์ชัย โลกประโคน',2,'2026-05-25 01:36:33'),(105,'B-18','พลฯ ศุภกฤต สดไธสง',2,'2026-05-25 01:36:33'),(106,'B-19','พลฯ ศิวกร มงคล',2,'2026-05-25 01:36:33'),(107,'B-20','พลฯ ชิติพัทธ์ ปานเจริญ',2,'2026-05-25 01:36:33'),(108,'B-21','พลฯ ทรงชัย รุ่งสว่าง',2,'2026-05-25 01:36:33'),(109,'B-22','พลฯ วรวุฒิ เผือกอำไพ',2,'2026-05-25 01:36:33'),(110,'B-23','พลฯ วิทวัส เมืองหมุด',2,'2026-05-25 01:36:33'),(111,'B-24','พลฯ รชต ด้วงสงค์',2,'2026-05-25 01:36:33'),(112,'B-25','พลฯ บุญสืบ เทียมพิทักษ์',2,'2026-05-25 01:36:33'),(113,'B-26','พลฯ วุฒิพงษ์ แซ่ลี้',2,'2026-05-25 01:36:33'),(114,'B-27','พลฯ กันต์พิจักษณ์ แจ่มฯ',2,'2026-05-25 01:36:33'),(115,'C-01','พลฯ ชุติพนธ์ ทรงฤทธิ์',3,'2026-05-25 01:36:33'),(116,'C-02','พลฯ วราวุธ อุปสาร',3,'2026-05-25 01:36:33'),(117,'C-03','พลฯ อมรเทพ กันหะบุตร',3,'2026-05-25 01:36:33'),(118,'C-04','พลฯ ธีระ กนิษฐะสุนทร',3,'2026-05-25 01:36:33'),(119,'C-05','พลฯ พีรพัฒน์ สังวาลย์',3,'2026-05-25 01:36:33'),(120,'C-06','พลฯ อิทธิพล บุตรอินทร์',3,'2026-05-25 01:36:33'),(121,'C-07','พลฯ ธีรเมธ แก้วถาวร',3,'2026-05-25 01:36:33'),(122,'C-08','พลฯ ธีรศาสนติ์ รัมมะศักดิ์',3,'2026-05-25 01:36:33'),(123,'C-09','พลฯ ณัฐวุฒิ ถิ่มตะเคียน',3,'2026-05-25 01:36:33'),(124,'C-10','พลฯ เทียนอดิสร เนติธนวัฒน์',3,'2026-05-25 01:36:33'),(125,'C-11','พลฯ ชัยรัช รจนากร',3,'2026-05-25 01:36:33'),(126,'C-12','พลฯ จตุพล ทองกระจาย',3,'2026-05-25 01:36:33'),(127,'C-13','พลฯ ภูวดล ทองทับ',3,'2026-05-25 01:36:33'),(128,'C-14','พลฯ กฤษณะ ทองอรุณ',3,'2026-05-25 01:36:33'),(129,'C-15','พลฯ ชัยพร ทองสะอาด',3,'2026-05-25 01:36:33'),(130,'C-16','พลฯ ศิวกร วงศ์หงษ์',3,'2026-05-25 01:36:33'),(131,'C-17','พลฯ รัฐกานต์ ยอดอาจ',3,'2026-05-25 01:36:33'),(132,'C-18','พลฯ หรรษา เพชรบรม',3,'2026-05-25 01:36:33'),(133,'C-19','พลฯ ชนะพงศ์ สังข์ปลื้ม',3,'2026-05-25 01:36:33'),(134,'C-20','พลฯ วัชระ ธนะประสิทธิ์',3,'2026-05-25 01:36:33'),(135,'C-21','พลฯ ยงยุทธ มุจริณร์',3,'2026-05-25 01:36:33'),(136,'C-22','พลฯ ภาณุพงษ์ หงษ์',3,'2026-05-25 01:36:33'),(137,'C-23','พลฯ ทินภัทร อิงชัยภูมิ',3,'2026-05-25 01:36:33'),(138,'C-24','พลฯ ทรงชัย สุวรรณชัยรบ',3,'2026-05-25 01:36:33'),(139,'C-25','พลฯ กฤตพล ลำเพยพล',3,'2026-05-25 01:36:33'),(140,'C-26','พลฯ ภูวมินทร์ ซุยคง',3,'2026-05-25 01:36:33'),(141,'C-27','พลฯ อภิเชษฐ ไชยโคตร',3,'2026-05-25 01:36:33'),(142,'C-28','พลฯ กิตติไชย แดงบุญเรือง',3,'2026-05-25 01:36:33'),(143,'C-29','พลฯ รัฐกานต์ มาช่วย',3,'2026-05-25 01:36:33');
/*!40000 ALTER TABLE `soldiers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `training_groups`
--

DROP TABLE IF EXISTS `training_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `training_groups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `group_code` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `group_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `training_groups`
--

LOCK TABLES `training_groups` WRITE;
/*!40000 ALTER TABLE `training_groups` DISABLE KEYS */;
INSERT INTO `training_groups` VALUES (1,'G1','หมวดฝึกที่ 1'),(2,'G2','หมวดฝึกที่ 2'),(3,'G3','หมวดฝึกที่ 3');
/*!40000 ALTER TABLE `training_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `urine_records`
--

DROP TABLE IF EXISTS `urine_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `urine_records` (
  `id` int NOT NULL AUTO_INCREMENT,
  `soldier_id` int NOT NULL,
  `record_date` date NOT NULL,
  `time_period` enum('M','A','E') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'M=Morning, A=Afternoon, E=Evening',
  `urine_level` tinyint DEFAULT NULL COMMENT '0-4',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_record` (`soldier_id`,`record_date`,`time_period`),
  CONSTRAINT `urine_records_ibfk_1` FOREIGN KEY (`soldier_id`) REFERENCES `soldiers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `urine_records`
--

LOCK TABLES `urine_records` WRITE;
/*!40000 ALTER TABLE `urine_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `urine_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `urine_monitoring_system`
--

USE `urine_monitoring_system`;

--
-- Final view structure for view `daily_summary`
--

/*!50001 DROP VIEW IF EXISTS `daily_summary`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_summary` AS select `urine_records`.`record_date` AS `record_date`,`urine_records`.`time_period` AS `time_period`,`urine_records`.`urine_level` AS `urine_level`,count(0) AS `total` from `urine_records` group by `urine_records`.`record_date`,`urine_records`.`time_period`,`urine_records`.`urine_level` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `full_report`
--

/*!50001 DROP VIEW IF EXISTS `full_report`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `full_report` AS select `ur`.`id` AS `id`,`ur`.`record_date` AS `record_date`,`ur`.`time_period` AS `time_period`,`ur`.`urine_level` AS `urine_level`,`s`.`soldier_code` AS `soldier_code`,`s`.`full_name` AS `full_name`,`tg`.`group_name` AS `group_name` from ((`urine_records` `ur` join `soldiers` `s` on((`ur`.`soldier_id` = `s`.`id`))) join `training_groups` `tg` on((`s`.`group_id` = `tg`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-25  9:19:10
