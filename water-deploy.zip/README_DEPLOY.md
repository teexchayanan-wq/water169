# Deploy Guide

## Requirements

- PHP 8.1 or newer
- MySQL or MariaDB
- Apache with `.htaccess` support

## Upload Files

Upload the project files to your hosting public folder, usually `public_html`.

Do not expose `db_config.php` publicly. The included `.htaccess` blocks direct access on Apache hosting.

## Create Database

1. Create a MySQL database in your hosting control panel.
2. Import `database.sql` with phpMyAdmin or the hosting database import tool.
3. Create a database user and give it access to that database.

## Configure Database

Copy `db_config.example.php` to `db_config.php` on the server, then edit:

```php
<?php
return [
    'db_host' => 'localhost',
    'db_user' => 'YOUR_DATABASE_USER',
    'db_pass' => 'YOUR_DATABASE_PASSWORD',
    'db_name' => 'YOUR_DATABASE_NAME',
    'admin_password' => 'CHANGE_THIS_ADMIN_PASSWORD'
];
```

Change `admin_password` before real use.

## URLs

- Data entry: `https://your-domain/index.html`
- Admin dashboard: `https://your-domain/admin.php`

## After Upload

1. Open `index.html` and save one test record.
2. Open `admin.php`, log in, and confirm the chart updates.
3. Use the admin button `จัดการรายชื่อพลทหาร` to confirm soldier roster editing saves to the database.

## Notes

- `admin.html` is intentionally blocked from direct browser access. Use `admin.php`.
- `save_soldiers.php` requires an admin login session.
- If your hosting uses Nginx instead of Apache, add equivalent deny rules for `db_config.php`, `auth.php`, `database.sql`, and direct `admin.html` access.
